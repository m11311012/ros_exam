#!/usr/bin/env python3
import rospy
from nav_msgs.msg import Odometry
from geometry_msgs.msg import PoseStamped

# 全局變量
pose_pub = None

def callback(msg):
    global pose_pub  # 宣告全局變量
    pose = PoseStamped()
    pose.header = msg.header
    pose.pose = msg.pose.pose  # 使用機器人的位置和姿態
    pose_pub.publish(pose)  # 發布轉換後的位置信息

def publish_robot_pose():
    global pose_pub  # 宣告全局變量
    rospy.init_node('robot_pose_broadcaster', anonymous=True)
    rospy.Subscriber('/odom', Odometry, callback)  # 訂閱 /odom 话题
    pose_pub = rospy.Publisher('/leader_pose', PoseStamped, queue_size=10)  # 定義發布者
    rospy.spin()

if __name__ == '__main__':
    try:
        publish_robot_pose()
    except rospy.ROSInterruptException:
        pass

