#!/usr/bin/env python3

import os
import subprocess

def open_new_terminal():
    # 要執行的 roslaunch 命令
    launch_command = "roslaunch m11311012 final_open_node.launch"

    # 在新的終端啟動命令（根據你的系統選擇正確的終端指令）
    terminal_command = f"gnome-terminal -e 'bash -c \"{launch_command}; exec bash\"'"
    
    # 執行命令
    subprocess.call(terminal_command, shell=True)

if __name__ == "__main__":
    open_new_terminal()

