#!/usr/bin/env python
import rospy
from geometry_msgs.msg import PoseStamped
from actionlib_msgs.msg import GoalStatusArray
from std_msgs.msg import Header
import time

# 定義每個房間的目標位置
ROOM_LOCATIONS = {
    1: {"x": -6.3, "y": -1.76, "z": 0.0, "ox": 0.0, "oy": 0.0, "oz": 0.0, "ow": 1.0},
    2: {"x": -6.12, "y": 3.11, "z": 0.0, "ox": 0.0, "oy": 0.0, "oz": 0.707, "ow": 0},
    3: {"x": -2.6, "y": 4.0, "z": 0.0, "ox": 0.0, "oy": 0.0, "oz": 1.0, "ow": 0.0},
    4: {"x": 1.12, "y": 2.28, "z": 0.0, "ox": 0.0, "oy": 0.0, "oz": -0.707, "ow": 0},
    5: {"x": 5.0, "y": 0.94, "z": 0.0, "ox": 0.0, "oy": 0.0, "oz": -1.0, "ow": 0.0},
    6: {"x": 5.95, "y": -1.57, "z": 0.0, "ox": 0.0, "oy": 0.0, "oz": -0.707, "ow": 0},
    7: {"x": 0.91, "y": -2.10, "z": 0.0, "ox": 0.0, "oy": 0.0, "oz": 0.0, "ow": 1.0},
}

# 記錄當前目標的狀態
current_goal_status = None

def goal_status_callback(msg):
    global current_goal_status
    if msg.status_list:
        current_goal_status = msg.status_list[0].status  # 確保只檢查最後一個目標的狀態
        #rospy.loginfo(f"目標狀態: {current_goal_status}")

def publish_goal(room_number):
    # 初始化ROS節點
    rospy.init_node('multi_point_navigation')
    
    # 檢查房間編號是否有效
    if room_number not in ROOM_LOCATIONS:
        rospy.logerr("無效的房間編號！")
        return

    # 獲取目標位置
    room = ROOM_LOCATIONS[room_number]

    # 創建PoseStamped消息
    goal = PoseStamped()
    goal.header = Header()
    goal.header.frame_id = "map"
    goal.header.stamp = rospy.Time.now()
    
    # 設定目標位置和方向
    goal.pose.position.x = room["x"]
    goal.pose.position.y = room["y"]
    goal.pose.position.z = room["z"]
    goal.pose.orientation.x = room["ox"]
    goal.pose.orientation.y = room["oy"]
    goal.pose.orientation.z = room["oz"]
    goal.pose.orientation.w = room["ow"]
    
    # 發佈目標位置
    
    goal_publisher = rospy.Publisher('/move_base_simple/goal', PoseStamped, queue_size=10)
    
    # 等待ROS系統啟動
    rospy.sleep(1)
    
    # 發佈目標
    
    rospy.loginfo(f"正在前往房間 {room_number} 的目標位置...")
    goal_publisher.publish(goal)
    

def main():
    global current_goal_status
    current_goal_status = 3 
    a=0

    # 初始化ROS節點
    rospy.init_node('multi_point_navigation')

    # 訂閱move_base狀態
    rospy.Subscriber('/move_base/status', GoalStatusArray, goal_status_callback)

    while not rospy.is_shutdown():
        try:
            if current_goal_status == 3 :
                if a == 1:
                    rospy.loginfo("到達目標!!!")
                    rospy.sleep(1)
                    a =0
                    
                room_number = int(input("請輸入房間編號 (1-7)，0 = 退出："))
                
                if room_number == 0:
                    break
                elif room_number < 0 or room_number > 7:
                    print("請輸入有效的房間編號 (1-7)！")
                    continue
             
            # 發佈目標位置
                publish_goal(room_number)
                

            # 等待機器人到達目標
                rospy.loginfo("等待機器人到達目標...")
                rospy.sleep(1)
            

            # 增加狀態檢查的等待時間，直到目標狀態變為3（已成功到達）
            if current_goal_status != 1:  # 3: 成功到達, 4: 被中斷, 5: 出現錯誤
                rospy.sleep(8)
                rospy.loginfo("尚未到達目標，請稍等...")
                a=1
                continue
            elif current_goal_status == 3:
                rospy.loginfo("到達目標!!!")
                rospy.sleep(1)
                
            
            

        except ValueError:
            print("無效輸入，請輸入一個數字！")

if __name__ == '__main__':
    main()

