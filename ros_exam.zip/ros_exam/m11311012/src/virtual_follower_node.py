#!/usr/bin/env python3
import rospy
from geometry_msgs.msg import PoseStamped, Twist
from visualization_msgs.msg import Marker
from math import atan2, sqrt

class VirtualFollower:
    def __init__(self):
        rospy.init_node('virtual_follower_node', anonymous=True)
        self.pose_sub = rospy.Subscriber('/leader_pose', PoseStamped, self.leader_callback)
        self.cmd_pub = rospy.Publisher('/follower_cmd_vel', Twist, queue_size=10)
        self.marker_pub = rospy.Publisher('/follower_marker', Marker, queue_size=10)

        self.target_x = 0
        self.target_y = 0
        self.current_x = 0
        self.current_y = 0
        self.follow_distance = 0.5  # 跟随距離
        self.rate = rospy.Rate(10)  # 10 Hz

    def leader_callback(self, msg):
        # 更新領導者的位置
        self.target_x = msg.pose.position.x
        self.target_y = msg.pose.position.y

    def follow_leader(self):
        while not rospy.is_shutdown():
            # 計算目標跟随點的位置
            dx = self.target_x - self.current_x
            dy = self.target_y - self.current_y

            distance = sqrt(dx**2 + dy**2)
            angle = atan2(dy, dx)

            twist = Twist()
            if distance > self.follow_distance:  # 如果距離大於設定距離
                twist.linear.x = 0.5 * distance
                twist.angular.z = 2.0 * angle
                self.current_x += 0.1 * distance * dx / distance
                self.current_y += 0.1 * distance * dy / distance
            else:
                twist.linear.x = 0
                twist.angular.z = 0

            self.cmd_pub.publish(twist)

            # 創建機器人模型，使用多个 Marker
            markers = []
            
            # 機器人身體
            body = Marker()
            body.header.frame_id = "map"
            body.header.stamp = rospy.Time.now()
            body.type = Marker.CUBE
            body.action = Marker.ADD
            body.pose.position.x = self.current_x
            body.pose.position.y = self.current_y
            body.pose.position.z = 0.5
            body.pose.orientation.w = 1.0
            body.scale.x = 0.5
            body.scale.y = 0.8
            body.scale.z = 0.2
            body.color.a = 1.0  # 完全不透明
            body.color.r = 0.0  # 红色
            body.color.g = 0.5  # 绿色
            body.color.b = 0.5
            markers.append(body)

            # 機器人頭部
            head = Marker()
            head.header.frame_id = "map"
            head.header.stamp = rospy.Time.now()
            head.type = Marker.CYLINDER
            head.action = Marker.ADD
            head.pose.position.x = self.current_x
            head.pose.position.y = self.current_y
            head.pose.position.z = 0.85  # 頭部位置
            head.pose.orientation.w = 1.0
            head.scale.x = 0.3  # 頭部半径
            head.scale.y = 0.3
            head.scale.z = 0.2  # 頭部高度
            head.color.a = 1.0
            head.color.r = 0.0
            head.color.g = 0.0
            head.color.b = 1.0  # 藍色
            markers.append(head)

            # 發布機器人模型（多个 Marker）
            for marker in markers:
                self.marker_pub.publish(marker)

            self.rate.sleep()

if __name__ == '__main__':
    try:
        follower = VirtualFollower()
        follower.follow_leader()
    except rospy.ROSInterruptException:
        pass

