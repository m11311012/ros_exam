#!/usr/bin/env python3
#coding = utf-8

import rospy
from geometry_msgs.msg import Twist       #有速度相關類型的包 Twist則是一種類型 他包刮了三軸的前進與旋轉
from pynput import keyboard               #引入 pynput 監看鍵盤
import math                               #引入 math 使用 pi

vel_msg = Twist()

# 鍵位的狀態
key_states = {
    'w': False,
    'a': False,
    's': False,
    'd': False,
    'o': False
    
}
#各個鍵位的代表速度
key_velocities = {
    'w': (0.5, 0),
    's': (-0.5, 0),
    'a': (0, 0.5),
    'd': (0, -0.5)
}
#要走得步驟 (繞一個8)
movement_eight = [                    
    (math.pi, math.pi),  
    (math.pi, -math.pi), 
    ]   


#根據按鍵設置的運動方式
def set_velocity():
    vel_msg.linear.x = 0       #讓沒有按按鍵時速度為0
    vel_msg.angular.z = 0

    linear, angular = 0, 0     #歸零上次的保持

    for key, (l, a) in key_velocities.items():     # 累加按下的按键速度 以達到同時案兩個按鍵的效果
        if key_states[key]:
            linear += l
            angular += a
 
    vel_msg.linear.x = linear                   # 設置機器人速度
    vel_msg.angular.z = angular

    if key_states['o']:                         #如果讀到 o 則執行 move_robot 函式
        move_robot(movement_eight)



    vel_pub.publish(vel_msg)                    #發布 訊息

#讀取按鍵按下 並更新狀態
def on_press(key):
    try:
        if key.char in key_states:
            key_states[key.char] = True
            set_velocity()
    except AttributeError:
        pass

#讀取按鍵鬆開 並更新狀態
def on_release(key):
    if key == keyboard.Key.esc:
        return False
    try:
        if key.char in key_states:
            key_states[key.char] = False
            set_velocity()
    except AttributeError:
        pass


def move_robot(move):

    for movement in move:
        linear_vel, angular_vel = movement
        vel_msg.linear.x = linear_vel
        vel_msg.angular.z = angular_vel
        vel_pub.publish(vel_msg)
        rospy.sleep(2)                   #走一個步驟花費的時間

if __name__ == "__main__":
    rospy.init_node("vel_node")
    vel_pub = rospy.Publisher("cmd_vel", Twist, queue_size=10)

    listener = keyboard.Listener(on_press=on_press, on_release=on_release) #設置監看者 並給予要執行的任務
    listener.start()      #開始監看 (內部以包含迴圈不需要使其在迴圈中也能持續執行)

    rospy.spin()
