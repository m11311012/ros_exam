#!/usr/bin/env python
import rospy
from std_msgs.msg import String
from geometry_msgs.msg import PoseStamped
from actionlib_msgs.msg import GoalStatusArray
from std_msgs.msg import Header

# 定义每个房间的目标位置
ROOM_LOCATIONS = {
    1: {"x": -6.3, "y": -1.76, "z": 0.0, "ox": 0.0, "oy": 0.0, "oz": 0.0, "ow": 1.0},
    2: {"x": -6.12, "y": 3.11, "z": 0.0, "ox": 0.0, "oy": 0.0, "oz": 0.707, "ow": 0},
    3: {"x": -2.6, "y": 4.0, "z": 0.0, "ox": 0.0, "oy": 0.0, "oz": 1.0, "ow": 0.0},
    4: {"x": 1.12, "y": 2.28, "z": 0.0, "ox": 0.0, "oy": 0.0, "oz": -0.707, "ow": 0},
    5: {"x": 5.0, "y": 0.94, "z": 0.0, "ox": 0.0, "oy": 0.0, "oz": -1.0, "ow": 0.0},
    6: {"x": 5.95, "y": -1.57, "z": 0.0, "ox": 0.0, "oy": 0.0, "oz": -0.707, "ow": 0},
    7: {"x": 0.91, "y": -2.10, "z": 0.0, "ox": 0.0, "oy": 0.0, "oz": 0.0, "ow": 1.0},
}

def room_number_callback(msg):
    room_number = int(msg.data)
    if room_number in ROOM_LOCATIONS:
        # 获取目标位置并发布
        room = ROOM_LOCATIONS[room_number]
        publish_goal(room)
    else:
        rospy.logwarn("Invalid room number received.")

def publish_goal(room):
    # 创建目标 PoseStamped 消息
    goal = PoseStamped()
    goal.header = Header()
    goal.header.frame_id = "map"
    goal.header.stamp = rospy.Time.now()

    goal.pose.position.x = room["x"]
    goal.pose.position.y = room["y"]
    goal.pose.position.z = room["z"]
    goal.pose.orientation.x = room["ox"]
    goal.pose.orientation.y = room["oy"]
    goal.pose.orientation.z = room["oz"]
    goal.pose.orientation.w = room["ow"]

    goal_publisher = rospy.Publisher('/move_base_simple/goal', PoseStamped, queue_size=10)
    rospy.loginfo(f"Publishing goal for room: {room}")
    goal_publisher.publish(goal)

def main():
    rospy.init_node('web_to_ros_navigation')

    # 订阅来自 Web 的房间编号
    rospy.Subscriber('/room_number', String, room_number_callback)

    rospy.spin()

if __name__ == '__main__':
    main()

